<?php require_once "core/auth.php"; ?>

<?php include "template/header.php"; ?>
    <h1>Dashboard</h1>
    <?php
       
    ?>
<?php include "template/footer.php"; ?>