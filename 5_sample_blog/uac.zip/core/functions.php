<?php
require_once "base.php";
//common start
function alert($data, $color = 'danger')
{
    return "<p class='alert alert-$color'>$data</p>";
}
function runQuery($sql){
    if (mysqli_query(con(), $sql)) {
        return true;
    }else{
        alert("DB Error");
    }
}
function redirect($l){
    header("location:$l");
}
//common end

//auth start

function register()
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if ($password == $cpassword) {
        $spass= password_hash($password,PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (name,email,password) VALUES ('$name','$email','$spass')";
        if(runQuery($sql)){
            redirect('login.php');
        }
    } else {
        return alert("Password & Confirm Password are not match!");
    }
}
function login(){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $query=mysqli_query(con(), $sql);
    $row=mysqli_fetch_assoc($query);
    if(!$row){
        return alert("Email or Password does not exit!");
    }else{
        if(!password_verify($password,$row['password'])){
           return alert("Email or Password does not match!");
        }else{
            // return alert("User info correct",'success');
            // redirect('index.php');
           session_start();
            $_SESSION['user'] = $row;
            redirect('dashboard.php');
        }
    }
}
   //auth end
